#!/bin/bash -l
#SBATCH -A uppmax2025-3-393 # Course project id. Change to your own project ID after the course
#SBATCH --time=00:10:00 # Asking for 10 minutes
#SBATCH -n 1 # Asking for 1 core

# Load any modules you need, here R/4.4.2  
module load R/4.4.2-gfbf-2024a 

# Run your R script (here 'hello.R')
Rscript add2.R 2 3 

